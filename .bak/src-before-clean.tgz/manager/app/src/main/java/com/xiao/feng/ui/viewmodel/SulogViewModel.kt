package com.xiao.feng.ui.viewmodel

import android.content.Context
import androidx.core.content.edit
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import com.xiao.feng.ksuApp
import com.xiao.feng.ui.util.*

data class SulogUiState(
    val isLoading: Boolean = true,
    val isRefreshing: Boolean = false,
    val sulogStatus: String = "",
    val isSulogEnabled: Boolean = false,
    val searchText: String = "",
    val selectedFilters: Set<SulogEventFilter> = defaultSulogEventFilters(),
    val files: List<SulogFile> = emptyList(),
    val selectedFilePath: String? = null,
    val entries: List<SulogEntry> = emptyList(),
    val visibleEntries: List<SulogEntry> = emptyList(),
    val errorMessage: String? = null,
)

class SulogViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(SulogUiState())
    val uiState: StateFlow<SulogUiState> = _uiState.asStateFlow()
    private val prefs = ksuApp.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val entriesFlow = MutableStateFlow<List<SulogEntry>>(emptyList())
    private val searchTextFlow = MutableStateFlow("")
    private val selectedFiltersFlow = MutableStateFlow(defaultSulogEventFilters())

    private var refreshJob: Job? = null

    init {
        val savedFilters = prefs.getStringSet(PREF_SULOG_FILTERS, null)
            ?.mapNotNull { raw -> SulogEventFilter.entries.firstOrNull { it.name == raw } }
            ?.toSet()
            ?.ifEmpty { defaultSulogEventFilters() }
            ?: defaultSulogEventFilters()
        selectedFiltersFlow.value = savedFilters
        _uiState.update { it.copy(selectedFilters = savedFilters) }

        viewModelScope.launch(Dispatchers.Default) {
            combine(entriesFlow, searchTextFlow, selectedFiltersFlow) { entries, searchText, selectedFilters ->
                buildVisibleSulogEntries(entries, searchText, selectedFilters)
            }.collect { visibleEntries ->
                _uiState.update { it.copy(visibleEntries = visibleEntries) }
            }
        }
    }

    fun refresh(preferredFilePath: String? = _uiState.value.selectedFilePath, refreshing: Boolean = false) {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(isLoading = !refreshing, isRefreshing = refreshing, errorMessage = null) }
            runCatching {
                val sulogStatus = getFeatureStatus("sulog")
                val isSulogEnabled = if (sulogStatus == "forced") {
                    getFeatureValue("sulog") == 1L
                } else {
                    getFeaturePersistValue("sulog") == 1L
                }
                val files = listSulogFiles()
                currentCoroutineContext().ensureActive()
                val selectedFile = when {
                    files.isEmpty() -> null
                    preferredFilePath != null -> files.firstOrNull { it.path == preferredFilePath } ?: files.first()
                    else -> files.first()
                }
                val logLines = selectedFile?.let { readSulogFile(it.path) }.orEmpty()
                val entries = parseSulogLines(logLines)
                val currentState = _uiState.value
                currentCoroutineContext().ensureActive()
                entriesFlow.value = entries
                SulogUiState(
                    isLoading = false,
                    isRefreshing = false,
                    sulogStatus = sulogStatus,
                    isSulogEnabled = isSulogEnabled,
                    searchText = currentState.searchText,
                    selectedFilters = currentState.selectedFilters,
                    files = files,
                    selectedFilePath = selectedFile?.path,
                    entries = entries,
                    visibleEntries = currentState.visibleEntries,
                )
            }.onSuccess { state ->
                _uiState.value = state
            }.onFailure { error ->
                if (error is kotlinx.coroutines.CancellationException) {
                    throw error
                }
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        isRefreshing = false,
                        errorMessage = error.message,
                    )
                }
            }
        }
    }

    fun refreshLatest(refreshing: Boolean = false) {
        refresh(preferredFilePath = null, refreshing = refreshing)
    }

    fun enableSulog() {
        val preferredFilePath = _uiState.value.selectedFilePath
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            if (execXfd("feature set sulog 1", true)) {
                execXfd("feature save", true)
            }
            refresh(preferredFilePath)
        }
    }

    fun cleanFile() {
        val currentState = _uiState.value
        val path = currentState.selectedFilePath ?: return
        val cleanAction = resolveSulogFileCleanAction(currentState.files, path)
        viewModelScope.launch(Dispatchers.IO) {
            when (cleanAction) {
                SulogFileCleanAction.Clear -> cleanSulogFile(path)
                SulogFileCleanAction.Delete -> deleteSulogFile(path)
            }
            refresh(path)
        }
    }

    fun setSearchText(searchText: String) {
        searchTextFlow.value = searchText
        _uiState.update { currentState ->
            currentState.copy(
                searchText = searchText,
            )
        }
    }

    fun toggleFilter(filter: SulogEventFilter) {
        _uiState.update { currentState ->
            val selectedFilters = currentState.selectedFilters.toMutableSet().apply {
                if (!add(filter)) remove(filter)
            }
            selectedFiltersFlow.value = selectedFilters
            prefs.edit {
                putStringSet(
                    PREF_SULOG_FILTERS,
                    selectedFilters.map { it.name }.toSet())
            }
            currentState.copy(
                selectedFilters = selectedFilters,
            )
        }
    }

    private companion object {
        const val PREF_SULOG_FILTERS = "sulog_filters"
    }
}
