package com.xiao.feng.ui.util

import android.app.Activity
import android.content.Intent
import android.content.ContentResolver
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.os.Environment
import android.os.Parcelable
import android.os.SystemClock
import android.provider.OpenableColumns
import android.system.Os
import android.util.Log
import com.xiao.feng.BuildConfig
import com.xiao.feng.Natives
import com.xiao.feng.R
import com.xiao.feng.ksuApp
import com.topjohnwu.superuser.CallbackList
import com.topjohnwu.superuser.Shell
import com.topjohnwu.superuser.ShellUtils
import com.topjohnwu.superuser.io.SuFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.parcelize.Parcelize
import org.json.JSONArray
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipFile

/**
 * @author weishu
 * @date 2023/1/1.
 */
private const val TAG = "XfCli"
private const val BUSYBOX = "/data/adb/ksu/bin/busybox"

private fun getXfDaemonPath(): String {
    return ksuApp.applicationInfo.nativeLibraryDir + File.separator + "libksud.so"
}

data class FlashResult(val code: Int, val err: String, val showReboot: Boolean) {
    constructor(result: Shell.Result, showReboot: Boolean) : this(result.code, result.err.joinToString("\n"), showReboot)
    constructor(result: Shell.Result) : this(result, result.isSuccess)
}

inline fun <T> withNewRootShell(
    globalMnt: Boolean = false,
    block: Shell.() -> T
): T {
    return createRootShell(globalMnt).use(block)
}

fun Uri.getFileName(context: Context): String? {
    var fileName: String? = null
    val contentResolver: ContentResolver = context.contentResolver
    val cursor: Cursor? = contentResolver.query(this, null, null, null, null)
    cursor?.use {
        if (it.moveToFirst()) {
            fileName = it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
        }
    }
    return fileName
}

fun createRootShellBuilder(globalMnt: Boolean = false): Shell.Builder {
    return Shell.Builder.create().run {
        val cmd = buildString {
            append("${getXfDaemonPath()} debug su")
            if (globalMnt) append(" -g")
            append(" || ")
            append("su")
            if (globalMnt) append(" --mount-master")
            append(" || ")
            append("sh")
        }
        setCommands("sh", "-c", cmd)
    }
}

fun createRootShell(globalMnt: Boolean = false): Shell {
    return runCatching {
        createRootShellBuilder(globalMnt).build()
    }.getOrElse { e ->
        Log.w(TAG, "su failed: ", e)
        Shell.Builder.create().apply {
            if (globalMnt) setFlags(Shell.FLAG_MOUNT_MASTER)
        }.build()
    }
}

fun execXfd(args: String, newShell: Boolean = false, globalMnt: Boolean = false): Boolean {
    return if (newShell) {
        withNewRootShell(globalMnt = globalMnt) {
            ShellUtils.fastCmdResult(this, "${getXfDaemonPath()} $args")
        }
    } else {
        ShellUtils.fastCmdResult("${getXfDaemonPath()} $args")
    }
}

suspend fun getFeatureStatus(feature: String): String = withContext(Dispatchers.IO) {
    val shell = createRootShell(true)
    
    val out = shell.newJob()
        .add("${getXfDaemonPath()} feature check $feature").to(ArrayList<String>(), null).exec().out
    out.firstOrNull()?.trim().orEmpty()
}

suspend fun getFeaturePersistValue(feature: String): Long? = readFeatureValue("--config $feature")

// Current value in kernel
suspend fun getFeatureValue(feature: String): Long? = readFeatureValue(feature)

private suspend fun readFeatureValue(args: String): Long? = withContext(Dispatchers.IO) {
    val shell = createRootShell(true)
    
    val out = shell.newJob()
        .add("${getXfDaemonPath()} feature get $args").to(ArrayList<String>(), null).exec().out
    val valueLine = out.firstOrNull { it.trim().startsWith("Value:") } ?: return@withContext null
    valueLine.substringAfter("Value:").trim().toLongOrNull()
}

fun install() {
    val start = SystemClock.elapsedRealtime()
    val libadbroot = File(ksuApp.applicationInfo.nativeLibraryDir, "libxfadb.so").absolutePath
    val result = execXfd("install --libadbroot $libadbroot", true)
    Log.w(TAG, "install result: $result, cost: ${SystemClock.elapsedRealtime() - start}ms")
}

fun listModules(): String {
    val out =
        Shell.cmd("${getXfDaemonPath()} module list").to(ArrayList(), null).exec().out
    return out.joinToString("\n").ifBlank { "[]" }
}

fun getModuleCount(): Int {
    return runCatching {
        JSONArray(listModules()).length()
    }.getOrDefault(0)
}

fun getSuperuserCount(): Int {
    return Natives.getSuperuserCount()
}

fun toggleModule(id: String, enable: Boolean): Boolean {
    val cmd = if (enable) {
        "module enable $id"
    } else {
        "module disable $id"
    }
    val result = execXfd(cmd, true)
    Log.i(TAG, "$cmd result: $result")
    return result
}

fun uninstallModule(id: String): Boolean {
    val cmd = "module uninstall $id"
    val result = execXfd(cmd, true)
    Log.i(TAG, "uninstall module $id result: $result")
    return result
}

fun restoreModule(id: String): Boolean {
    val cmd = "module restore $id"
    val result = execXfd(cmd, true)
    Log.i(TAG, "restore module $id result: $result")
    return result
}

fun getSelinuxEnforce(): Boolean? {
    return runCatching {
        val out = ShellUtils.fastCmd("getenforce").trim()
        when {
            out.equals("Enforcing", ignoreCase = true) -> true
            out.equals("Permissive", ignoreCase = true) -> false
            else -> null
        }
    }.getOrNull()
}

fun setSelinuxEnforce(enforce: Boolean): Boolean {
    return runCatching {
        val valStr = if (enforce) "1" else "0"
        ShellUtils.fastCmdResult("setenforce $valStr")
    }.getOrDefault(false)
}

private fun processUiPrintLine(s: String?): Pair<Int, String?> {
    if (s == null) {
        return Pair(1,null)
    }

    val check1 = s.startsWith("ui_print")
    val trimmed = s.trim()
    val check2 = trimmed.startsWith("ui_print")
    if (!check1 && check2) return Pair(1,null)

    return if(check1) {
        Pair(1,trimmed.drop(8).dropWhile { it.isWhitespace() })
    }
    else {
        Pair(2, trimmed)
    }
}

private fun flashWithIO_ak3(
    cmd: String,
    onStdout: (String) -> Unit,
    onStderr: (String) -> Unit
): Shell.Result {

    val stdoutCallback: CallbackList<String?> = object : CallbackList<String?>() {
        override fun onAddElement(s: String?) {
            val (type, text) = processUiPrintLine(s)
            if(type == 1) {
                text?.let(onStdout)
            } else {
                text?.let(onStderr)
            }
        }
    }

    val stderrCallback: CallbackList<String?> = object : CallbackList<String?>() {
        override fun onAddElement(s: String?) {
            onStderr(s ?: "")
        }
    }

    return withNewRootShell {
        newJob().add(cmd).to(stdoutCallback, stderrCallback).exec()
    }
}

private fun flashWithIO(
    cmd: String,
    onStdout: (String) -> Unit,
    onStderr: (String) -> Unit
): Shell.Result {

    val stdoutCallback: CallbackList<String?> = object : CallbackList<String?>() {
        override fun onAddElement(s: String?) {
            onStdout(s ?: "")
        }
    }

    val stderrCallback: CallbackList<String?> = object : CallbackList<String?>() {
        override fun onAddElement(s: String?) {
            onStderr(s ?: "")
        }
    }

    return withNewRootShell {
        newJob().add(cmd).to(stdoutCallback, stderrCallback).exec()
    }
}

fun flashModule(
    uri: Uri,
    onStdout: (String) -> Unit,
    onStderr: (String) -> Unit
): FlashResult {
    val resolver = ksuApp.contentResolver
    with(resolver.openInputStream(uri)) {
        val file = File(ksuApp.cacheDir, "module.zip")
        file.outputStream().use { output ->
            this?.copyTo(output)
        }
        val cmd = "module install ${file.absolutePath}"
        val result = flashWithIO("${getXfDaemonPath()} $cmd", onStdout, onStderr)
        Log.i("XiaoFeng", "install module $uri result: $result")

        val showReboot = result.isSuccess && moduleNeedsReboot(file)
        file.delete()

        return FlashResult(result, showReboot)
    }
}

private val MODULE_ID_REGEX = Regex("^[a-zA-Z][a-zA-Z0-9._-]+$")

// A hot installed module goes live without leaving the "update" flag behind
private fun moduleNeedsReboot(zip: File): Boolean {
    val id = runCatching {
        ZipFile(zip).use { archive ->
            val entry = archive.getEntry("module.prop") ?: return@use null
            archive.getInputStream(entry).bufferedReader().useLines { lines ->
                lines.map { it.trim() }.firstOrNull { it.startsWith("id=") }?.substringAfter('=')?.trim()
            }
        }
    }.getOrNull()
    if (id == null || !MODULE_ID_REGEX.matches(id)) return true
    val dir = "/data/adb/modules/$id"
    // Any failure to check counts as needing a reboot
    return !ShellUtils.fastCmdResult("[ -d $dir ] && [ ! -e $dir/update ]")
}

fun runModuleAction(
    moduleId: String, onStdout: (String) -> Unit, onStderr: (String) -> Unit
): Boolean {
    val shell = createRootShell(true)

    val stdoutCallback: CallbackList<String?> = object : CallbackList<String?>() {
        override fun onAddElement(s: String?) {
            onStdout(s ?: "")
        }
    }

    val stderrCallback: CallbackList<String?> = object : CallbackList<String?>() {
        override fun onAddElement(s: String?) {
            onStderr(s ?: "")
        }
    }

    val result = shell.newJob().add("${getXfDaemonPath()} module action $moduleId")
        .to(stdoutCallback, stderrCallback).exec()
    Log.i("XiaoFeng", "Module runAction result: $result")

    return result.isSuccess
}

fun restoreBoot(
    onStdout: (String) -> Unit, onStderr: (String) -> Unit
): FlashResult {
    val result = flashWithIO("${getXfDaemonPath()} boot-restore -f", onStdout, onStderr)
    return FlashResult(result)
}

fun uninstallPermanently(
    onStdout: (String) -> Unit, onStderr: (String) -> Unit
): FlashResult {
    val result = flashWithIO("${getXfDaemonPath()} uninstall --package-name ${BuildConfig.APPLICATION_ID}", onStdout, onStderr)
    return FlashResult(result)
}

@Parcelize
sealed class LkmSelection : Parcelable {
    data class LkmUri(val uri: Uri) : LkmSelection()
    data class KmiString(val value: String) : LkmSelection()
    data object KmiNone : LkmSelection()
}

fun installBoot(
    bootUri: Uri?,
    lkm: LkmSelection,
    ota: Boolean,
    allowShell: Boolean,
    enableAdb: Boolean,
    onStdout: (String) -> Unit,
    onStderr: (String) -> Unit,
): FlashResult {
    val resolver = ksuApp.contentResolver

    val bootFile = bootUri?.let { uri ->
        with(resolver.openInputStream(uri)) {
            val bootFile = File(ksuApp.cacheDir, "boot.img")
            bootFile.outputStream().use { output ->
                this?.copyTo(output)
            }

            bootFile
        }
    }

    var cmd = "boot-patch"

    cmd += if (bootFile == null) {
        // no boot.img, use -f to force install
        " -f"
    } else {
        " -b ${bootFile.absolutePath}"
    }

    if (allowShell) {
        cmd += " --allow-shell"
    }

    if (enableAdb) {
        cmd += " --enable-adbd"
    }

    if (ota) {
        cmd += " -u"
    }

    var lkmFile: File? = null
    when (lkm) {
        is LkmSelection.LkmUri -> {
            lkmFile = with(resolver.openInputStream(lkm.uri)) {
                val file = File(ksuApp.cacheDir, "xiaofeng-tmp-lkm.ko")
                file.outputStream().use { output ->
                    this?.copyTo(output)
                }

                file
            }
            cmd += " -m ${lkmFile.absolutePath}"
        }

        is LkmSelection.KmiString -> {
            cmd += " --kmi ${lkm.value}"
        }

        LkmSelection.KmiNone -> {
            // do nothing
        }
    }

    // output dir
    val downloadsDir =
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
    cmd += " -o $downloadsDir"

    val result = flashWithIO("${getXfDaemonPath()} $cmd", onStdout, onStderr)
    Log.i("XiaoFeng", "install boot result: ${result.isSuccess}")

    bootFile?.delete()
    lkmFile?.delete()

    // if boot uri is empty, it is direct install, when success, we should show reboot button
    return FlashResult(result, bootUri == null && result.isSuccess)
}

fun reboot(reason: String = "") {
    if (reason == "soft-reboot") {
        // ksud (userspace)
        com.xiao.feng.ui.util.execXfd("soft-reboot", true, true)
        return
    }

    if (reason == "recovery") {
        // KEYCODE_POWER = 26, hide incorrect "Factory data reset" message
        ShellUtils.fastCmdResult("/system/bin/input keyevent 26")
    }
    ShellUtils.fastCmdResult("/system/bin/svc power reboot $reason || /system/bin/reboot $reason")
}

fun flashAnyKernelZip(
    uri: Uri,
    onStdout: (String) -> Unit,
    onStderr: (String) -> Unit
): FlashResult {
    val resolver = ksuApp.contentResolver

    val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
    val tmpFile = File(ksuApp.cacheDir, "anykernel_${timestamp}.zip")
    resolver.openInputStream(uri).use { input ->
        tmpFile.outputStream().use { out ->
            input?.copyTo(out)
        }
    }

    val destZip = tmpFile.absolutePath
    val destZipName = File(destZip).name
    val destDirFile = File(ksuApp.cacheDir, "anykernel3_${timestamp}")
    val destDir = destDirFile.absolutePath

    // Validate that the zip contains the required META-INF installer script
    val hasInstaller = runCatching {
        java.util.zip.ZipFile(tmpFile).use { zip ->
            zip.getEntry("META-INF/com/google/android/update-binary") != null
        }
    }.getOrDefault(false)

    if (!hasInstaller) {
        tmpFile.delete()
        val errMsg = "Invalid AnyKernel3 zip: META-INF/com/google/android/update-binary not found!"
        onStderr(errMsg)
        return FlashResult(1, "", false)
    }

    val cmd = """
                mkdir -p '$destDir' && \
                $BUSYBOX unzip -p -o '$destZip' "META-INF/com/google/android/update-binary" > '$destDir/update-binary' 2>/dev/null && \
                cp '$destZip' '$destDir/$destZipName' 2>/dev/null || true && \
                $BUSYBOX chmod 755 '$destDir/update-binary' && \
                $BUSYBOX chown root:root '$destDir/update-binary' && \
                (cd '$destDir' && \
                    if [ -f './update-binary' ]; then \
                        AKHOME='$destDir/tmp' $BUSYBOX ash '$destDir/update-binary' 3 1 '$destDir/$destZipName'; \
                    else \
                        echo 'No installer script found' >&2; exit 1; \
                    fi)
            """.trimIndent().replace(Regex("\\s+\\\\\\s*"), " ")

    val result = flashWithIO_ak3(cmd, onStdout, onStderr)
    try {
        return FlashResult(result, result.isSuccess)
    } finally {
        try {
            runCatching {
                createRootShell(true).use { sh ->
                    sh.newJob().add("rm -rf '$destDir' '$destZip'").exec()
                }
            }
        } catch (_: Throwable) {
        }
    }
}

fun rootAvailable() = Shell.isAppGrantedRoot() == true

fun isInitBoot(): Boolean {
    return !Os.uname().release.contains("android12-")
}

suspend fun getCurrentKmi(): String = withContext(Dispatchers.IO) {
    val cmd = "boot-info current-kmi"
    ShellUtils.fastCmd("${getXfDaemonPath()} $cmd")
}

suspend fun getSupportedKmis(): List<String> = withContext(Dispatchers.IO) {
    val cmd = "boot-info supported-kmis"
    val out = Shell.cmd("${getXfDaemonPath()} $cmd").to(ArrayList(), null).exec().out
    out.filter { it.isNotBlank() }.map { it.trim() }
}

fun loadSusfsGuardLkm(kmi: String? = null): Boolean {
    val args = buildString {
        append("susfs load")
        if (kmi != null) {
            require(kmi.matches(Regex("[A-Za-z0-9._-]+"))) { "Invalid KMI: $kmi" }
            append(" --kmi ")
            append(kmi)
        }
    }
    return execXfd(args, newShell = true, globalMnt = true)
}

fun unloadSusfsGuardLkm(): Boolean =
    execXfd("susfs unload", newShell = true, globalMnt = true)

suspend fun isSusfsGuardLkmLoaded(): Boolean = withContext(Dispatchers.IO) {
    createRootShell(true).newJob()
        .add("test -d /sys/module/susfs_guard_lkm")
        .exec()
        .isSuccess
}

suspend fun getSusfsAutoLoadEnabled(): Boolean = withContext(Dispatchers.IO) {
    val shell = createRootShell(true)
    val result = shell.newJob()
        .add("${getXfDaemonPath()} susfs autoload status")
        .to(ArrayList<String>(), null)
        .exec()
    result.isSuccess && result.out.any { it.trim() == "enabled" }
}

fun setSusfsAutoLoadEnabled(enabled: Boolean, fallbackKmi: String? = null): Boolean {
    val args = if (enabled) {
        require(fallbackKmi != null && fallbackKmi.matches(Regex("[A-Za-z0-9._-]+"))) {
            "A valid KMI is required to enable SUSFS auto-load"
        }
        "susfs autoload enable --kmi $fallbackKmi"
    } else {
        "susfs autoload disable"
    }
    return execXfd(args, newShell = true, globalMnt = true)
}

suspend fun isAbDevice(): Boolean = withContext(Dispatchers.IO) {
    val cmd = "boot-info is-ab-device"
    ShellUtils.fastCmd("${getXfDaemonPath()} $cmd").trim().toBoolean()
}

suspend fun getDefaultPartition(): String = withContext(Dispatchers.IO) {
    if (rootAvailable()) {
        val cmd = "boot-info default-partition"
        ShellUtils.fastCmd("${getXfDaemonPath()} $cmd").trim()
    } else {
        if (!Os.uname().release.contains("android12-")) "init_boot" else "boot"
    }
}

suspend fun getSlotSuffix(ota: Boolean): String = withContext(Dispatchers.IO) {
    val cmd = if (ota) {
        "boot-info slot-suffix --ota"
    } else {
        "boot-info slot-suffix"
    }
    ShellUtils.fastCmd("${getXfDaemonPath()} $cmd").trim()
}

suspend fun getAvailablePartitions(): List<String> = withContext(Dispatchers.IO) {
    val shell = createRootShell(true)
    val cmd = "boot-info available-partitions"
    val out = shell.newJob().add("${getXfDaemonPath()} $cmd").to(ArrayList(), null).exec().out
    out.filter { it.isNotBlank() }.map { it.trim() }
}

fun hasMagisk(): Boolean {
    val result = ShellUtils.fastCmdResult("which magisk")
    Log.i(TAG, "has magisk: $result")
    return result
}

fun isSepolicyValid(rules: String?): Boolean {
    if (rules == null) {
        return true
    }
    val result =
        Shell.cmd("${getXfDaemonPath()} sepolicy check '$rules'").to(ArrayList(), null)
            .exec()
    return result.isSuccess
}

fun getSepolicy(pkg: String): String {
    val result =
        Shell.cmd("${getXfDaemonPath()} profile get-sepolicy $pkg").to(ArrayList(), null)
            .exec()
    Log.i(TAG, "code: ${result.code}, out: ${result.out}, err: ${result.err}")
    return result.out.joinToString("\n")
}

fun setSepolicy(pkg: String, rules: String): Boolean {
    val result = Shell.cmd("${getXfDaemonPath()} profile set-sepolicy $pkg '$rules'")
        .to(ArrayList(), null).exec()
    Log.i(TAG, "set sepolicy result: ${result.code}")
    return result.isSuccess
}

fun listAppProfileTemplates(): List<String> {
    return Shell.cmd("${getXfDaemonPath()} profile list-templates").to(ArrayList(), null)
        .exec().out
}

fun getAppProfileTemplate(id: String): String {
    return Shell.cmd("${getXfDaemonPath()} profile get-template '${id}'")
        .to(ArrayList(), null).exec().out.joinToString("\n")
}

fun getFileName(context: Context, uri: Uri): String {
    var name = context.getString(R.string.module_unknown)
    if (uri.scheme == ContentResolver.SCHEME_CONTENT) {
        val cursor: Cursor? = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                name = it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
            }
        }
    } else if (uri.scheme == "file") {
        name = uri.lastPathSegment ?: context.getString(R.string.module_unknown)
    }
    return name
}

fun currentMountSystem(): String {
    val result = ShellUtils.fastCmd("${getXfDaemonPath()} module mount").trim()
    return result.substringAfter(":").substringAfter(" ").trim()
}

fun getModuleSize(dir: File): Long {
    val result = ShellUtils.fastCmd("$BUSYBOX du -sb '${dir.absolutePath}' | awk '{print $1}'").trim()
    return result.toLongOrNull() ?: 0L
}

fun isSuCompatDisabled(): Boolean {
    return !Natives.isSuEnabled()
}

fun zygiskRequired(dir: File): Boolean {
    return (SuFile(dir, "zygisk").listFiles()?.size ?: 0) > 0
}

fun isZygiskImpl(dir: File): Boolean {
    return SuFile(dir, "bin/zygiskd").exists() || SuFile(dir, "bin/zygiskd64").exists()
}

fun refreshActivity(context: Context) {
    if (context is Activity) {
        context.recreate()
    }
}

fun restartActivity(context: Context) {
    val packageManager = context.packageManager
    val intent = packageManager.getLaunchIntentForPackage(context.packageName)
    intent?.addFlags(
        Intent.FLAG_ACTIVITY_NEW_TASK or
        Intent.FLAG_ACTIVITY_CLEAR_TASK or
        Intent.FLAG_ACTIVITY_CLEAR_TOP
    )
    context.startActivity(intent)
    if (context is Activity) {
        context.finish()
    }
}

fun getSuSFS(): String {
    return ShellUtils.fastCmd("${getXfDaemonPath()} susfs support")
}

fun getSuSFSVersion(): String {
    return ShellUtils.fastCmd("${getXfDaemonPath()} susfs version")
}

fun getSuSFSVariant(): String {
    return ShellUtils.fastCmd("${getXfDaemonPath()} susfs variant")
}

fun getSuSFSFeatures(): String {
    return ShellUtils.fastCmd("${getXfDaemonPath()} susfs features")
}

fun getMetaModule(): String {
    return ShellUtils.fastCmd("${getXfDaemonPath()} module metamodule")
}

fun setAppProfileTemplate(id: String, template: String): Boolean {
    val escapedTemplate = template.replace("'", "'\\''")
    val cmd = """${getXfDaemonPath()} profile set-template "$id" '$escapedTemplate'"""
    return Shell.cmd(cmd)
        .to(ArrayList(), null).exec().isSuccess
}

fun deleteAppProfileTemplate(id: String): Boolean {
    return Shell.cmd("${getXfDaemonPath()} profile delete-template '${id}'")
        .to(ArrayList(), null).exec().isSuccess
}

fun forceStopApp(packageName: String) {
    val result = Shell.cmd("am force-stop $packageName").exec()
    Log.i(TAG, "force stop $packageName result: $result")
}

fun launchApp(packageName: String) {
    val result =
        Shell.cmd("cmd package resolve-activity --brief $packageName | tail -n 1 | xargs cmd activity start-activity -n")
            .exec()
    Log.i(TAG, "launch $packageName result: $result")
}

fun restartApp(packageName: String) {
    forceStopApp(packageName)
    launchApp(packageName)
}

fun getRiskStatus(): Boolean? {
    return runCatching {
        val out = ShellUtils
            .fastCmd("${getXfDaemonPath()} module risk status")
            .trim()

        when {
            out.equals("Enabled", ignoreCase = true) -> true
            out.equals("Disabled", ignoreCase = true) -> false
            else -> null
        }
    }.getOrNull()
}

fun setRisk(enabled: Boolean): Boolean {
    return runCatching {
        val command = if (enabled) "enable" else "disable"

        ShellUtils.fastCmdResult(
            "${getXfDaemonPath()} module risk $command"
        )
    }.getOrDefault(false)
}

fun nonRootShell(command: String): Boolean {
    val process = ProcessBuilder("sh", "-c", command)
        .redirectErrorStream(true)
        .start()
    process.inputStream.bufferedReader().readText()
    return process.waitFor() == 0
}
